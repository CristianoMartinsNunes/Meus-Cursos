create table produto 
(id integer auto_increment primary key, 
nome varchar(255), 
preco decimal(10,2));

create table categoria 
(id integer auto_increment primary key, 
nome varchar(255));

insert into categoria (nome) 
values ('esporte'),('frios'),('bebidas');

select * from categoria;

alter table produto
add id_categoria int;

select * from produto;

alter table produto
add usado boolean default 0;
