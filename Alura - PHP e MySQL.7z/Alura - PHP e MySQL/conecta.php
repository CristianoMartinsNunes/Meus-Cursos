<?php

	$conexao = mysqli_connect("localhost","root","root","alura_loja");
?>