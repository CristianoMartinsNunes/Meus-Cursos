<?php

function insereProduto($conexao, $nome, $preco, $descricao, $categoria_id, $usado){
	$query = "insert into produto (nome, preco, descricao, id_categoria, usado) values ('{$nome}', {$preco}, '{$descricao}', {$categoria_id}, {$usado})";
	return mysqli_query($conexao,$query);
}


function listaProduto($conexao){

	$produtos = array();
	$resultado = mysqli_query($conexao,"SELECT p.*, c.nome as categoria_nome FROM PRODUTO as p inner join categoria as c on c.id=p.id_categoria");

	while ($produto = mysqli_fetch_assoc($resultado)) 
	{	
		array_push($produtos, $produto);
	}

	return $produtos;
}

function removeProduto($conexao,$id){

	$query = "DELETE FROM PRODUTO WHERE id = {$id}";
	return mysqli_query($conexao, $query);
}

function buscaProduto($conexao, $id){
	$query = "SELECT * FROM PRODUTO WHERE ID = {$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}

function alteraProduto($conexao, $id, $nome, $preco, $descricao, $categoria_id, $usado){
	$query = "update produto set nome ='{$nome}', preco = {$preco}, descricao = '{$descricao}', id_categoria = {$categoria_id}, usado = {$usado} where id = '{$id}'";

	return mysqli_query($conexao, $query);
}



?>